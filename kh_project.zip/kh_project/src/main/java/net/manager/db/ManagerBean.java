package net.manager.db;

public class ManagerBean {

	private int P_NUM; 
	private String P_NAME; 
	private int P_LEVEL; 
	private String P_CONTENT; 
	private String P_FILE;
	private String P_PRE;
	private String P_PLACE;
	
	public String getP_PRE() {
		return P_PRE;
	}
	public void setP_PRE(String p_PRE) {
		P_PRE = p_PRE;
	}
	public String getP_PLACE() {
		return P_PLACE;
	}
	public void setP_PLACE(String p_PLACE) {
		P_PLACE = p_PLACE;
	}
	public int getP_NUM() {
		return P_NUM;
	}
	public void setP_NUM(int p_NUM) {
		P_NUM = p_NUM;
	}
	public String getP_NAME() {
		return P_NAME;
	}
	public void setP_NAME(String p_NAME) {
		P_NAME = p_NAME;
	}
	public int getP_LEVEL() {
		return P_LEVEL;
	}
	public void setP_LEVEL(int p_LEVEL) {
		P_LEVEL = p_LEVEL;
	}
	public String getP_CONTENT() {
		return P_CONTENT;
	}
	public void setP_CONTENT(String p_CONTENT) {
		P_CONTENT = p_CONTENT;
	}
	public String getP_FILE() {
		return P_FILE;
	}
	public void setP_FILE(String p_FILE) {
		P_FILE = p_FILE;
	}
}
