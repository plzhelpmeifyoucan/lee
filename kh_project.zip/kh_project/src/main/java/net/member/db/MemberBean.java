package net.member.db;

public class MemberBean { // DTO(데이터 전달용)

	private String KH_ID;
	private String KH_PW;
	private String KH_NAME;
	private String KH_TEL;
	public String getKH_ID() {
		return KH_ID;
	}
	public void setKH_ID(String kH_ID) {
		KH_ID = kH_ID;
	}
	public String getKH_PW() {
		return KH_PW;
	}
	public void setKH_PW(String kH_PW) {
		KH_PW = kH_PW;
	}
	public String getKH_NAME() {
		return KH_NAME;
	}
	public void setKH_NAME(String kH_NAME) {
		KH_NAME = kH_NAME;
	}
	public String getKH_TEL() {
		return KH_TEL;
	}
	public void setKH_TEL(String kH_TEL) {
		KH_TEL = kH_TEL;
	}
	
	
}
