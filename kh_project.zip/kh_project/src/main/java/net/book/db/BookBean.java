package net.book.db;

public class BookBean {

	private int B_NUM;
	private String B_PRODUCT;
	private String B_NAME;
	private String B_DATE;
	private int B_PNUM;
	private String B_TEL;
	private int B_INWON;
	private String B_ID;
	private String B_TIME;
	
	
	public String getB_TIME() {
		return B_TIME;
	}
	public void setB_TIME(String b_TIME) {
		B_TIME = b_TIME;
	}
	public String getB_ID() {
		return B_ID;
	}
	public void setB_ID(String b_ID) {
		B_ID = b_ID;
	}
	public String getB_TEL() {
		return B_TEL;
	}
	public void setB_TEL(String b_TEL) {
		B_TEL = b_TEL;
	}
	public int getB_INWON() {
		return B_INWON;
	}
	public void setB_INWON(int b_INWON) {
		B_INWON = b_INWON;
	}
	public int getB_NUM() {
		return B_NUM;
	}
	public void setB_NUM(int b_NUM) {
		B_NUM = b_NUM;
	}
	public String getB_PRODUCT() {
		return B_PRODUCT;
	}
	public void setB_PRODUCT(String b_PRODUCT) {
		B_PRODUCT = b_PRODUCT;
	}
	public String getB_NAME() {
		return B_NAME;
	}
	public void setB_NAME(String b_NAME) {
		B_NAME = b_NAME;
	}
	public int getB_PNUM() {
		return B_PNUM;
	}
	public void setB_PNUM(int b_PNUM) {
		B_PNUM = b_PNUM;
	}
	public String getB_DATE() {
		return B_DATE;
	}
	public void setB_DATE(String b_DATE) {
		B_DATE = b_DATE;
	}

	
	
}
